"""Hard validity gate. No formal training occurs here. 100-step probes discarded."""
from pathlib import Path
import json,time,gc,copy,traceback,hashlib
import numpy as np
import torch
from model_cssm import build,ROOT,STAGES,SPATIAL,common_state,statehash,med_state_hash,PARENT,build_baseline
from protocol_cssm import *
def save_payload(path,payload):
 tmp=path.with_suffix('.tmp');torch.save(payload,tmp);tmp.replace(path)
def finite(model):
 assert all(torch.isfinite(p).all() for p in model.parameters())
def gradstats(model):
 groups={}
 for n,p in model.named_parameters():
  if not p.requires_grad:assert p.grad is None;continue
  assert p.grad is not None and torch.isfinite(p.grad).all(),n
  g='global_projection' if 'global_projection' in n else 'spatial_projections' if 'spatial_projections' in n else 'adaLN' if 'adaLN_modulation' in n else 'other'
  groups[g]=groups.get(g,0.)+float(p.grad.detach().square().sum())
 return {k:v**.5 for k,v in groups.items()}
def test(mode,batch,common,parent_out,xx,t):
 seed();m=build(mode,common).cuda();u=m.model.unet0;m.eval()
 d=Pairs('train');s=Stream(d);x,y,meta=s.next(batch);x=x.cuda();y=y.cuda()
 frozen=med_state_hash(m)
 with torch.no_grad():
  u.set_context(x)
  active=u(xx,t).cpu()
  u.branch_off=True;off=u(xx,t).cpu();u.branch_off=False
  assert torch.equal(off,parent_out), 'Disabled DACB does not reproduce exact parent output'
  assert torch.allclose(active,parent_out,atol=1e-6,rtol=1e-6),f'Step0 differs {float((active-parent_out).abs().max())}'
  assert u.extract_calls==(0 if mode=='CONTROL' else 1)
  u.clear_context()
 opt=torch.optim.Adam((p for p in m.parameters() if p.requires_grad),lr=2e-4,betas=(.9,.99),weight_decay=1e-9)
 em=copy.deepcopy(m).eval().requires_grad_(False)
 gens=torch.Generator(device='cuda').manual_seed(20260829)
 torch.cuda.reset_peak_memory_stats();records=[];total=0.
 for step in range(1,101):
  start=time.perf_counter();m.train();opt.zero_grad(set_to_none=True)
  x,y,meta=s.next(batch);x=x.cuda();y=y.cuda();tt=torch.randint(0,1000,(batch,),device='cuda',generator=gens);noise=torch.randn(x.shape,device='cuda',generator=gens)
  u.set_context(x)
  loss=m.p_losses([y*2-1,x*2-1],tt,noise)[0]
  assert torch.isfinite(loss)
  loss.backward()
  g=gradstats(m)
  norm=torch.nn.utils.clip_grad_norm_((p for p in m.parameters() if p.requires_grad),1.0,error_if_nonfinite=True)
  opt.step();u.clear_context()
  with torch.no_grad():
   for ep,p in zip(em.parameters(),m.parameters()):
    if p.requires_grad:ep.mul_(.995).add_(p,alpha=.005)
    else:ep.copy_(p)
  finite(m);torch.cuda.synchronize()
  secs=time.perf_counter()-start;total+=secs
  if step in (1,2,3,10,100):
   row={'step':step,'loss':float(loss.detach()),'grad_norm_pre_clip':float(norm),'gradient_groups':g,'seconds':secs};records.append(row);print(mode,row,flush=True)
  if step==2 and mode!='CONTROL':assert g.get('global_projection',0)>0, 'Global projection did not receive gradient after gate update'
  if step==2 and mode=='MED_S':assert g.get('spatial_projections',0)>0, 'Spatial projection did not receive gradient after gate update'
 assert med_state_hash(m)==frozen
 allocated=torch.cuda.max_memory_allocated()/2**30;reserved=torch.cuda.max_memory_reserved()/2**30
 assert allocated<23, 'Safety limit before formal training'
 result={'variant':mode,'batch':batch,'steps':100,'counted_in_formal':False,'step0_branch_off_parent_bitwise_equal':True,'step0_active_max_diff':float((active-parent_out).abs().max()),'mean_sec_per_step':total/100,'peak_allocated_GiB':allocated,'peak_reserved_GiB':reserved,'trainable_parameters':sum(p.numel() for p in m.parameters() if p.requires_grad),'all_parameters':sum(p.numel() for p in m.parameters()),'frozen_med_hash_before':frozen,'frozen_med_hash_after':med_state_hash(m),'records':records,'nan_inf_overflow_optimizer_skip':0,'initial_common_hash':statehash(common),'effective_d_inner':{s:u.dacb[s].mamba.d_inner for s in STAGES}}
 del opt,em,m;gc.collect();torch.cuda.empty_cache()
 return result
def main():
 assert json.loads((ROOT/'runtime/KERNEL_WITNESS.json').read_text())['status']=='PASS'
 seed();cpu=build('CONTROL');common=common_state(cpu);commonhash=statehash(common)
 if (ROOT/'COMMON_INITIAL_STATE.pt').exists():
  prior=torch.load(ROOT/'COMMON_INITIAL_STATE.pt',map_location='cpu',weights_only=False)
  assert statehash(prior['common_state'])==commonhash and prior['hash']==commonhash
 else:
  save_payload(ROOT/'COMMON_INITIAL_STATE.pt',{'common_state':common,'hash':commonhash,'parent_sha':sha(PARENT)})
 parent=build_baseline();parent.load_state_dict(torch.load(PARENT,map_location='cpu',weights_only=False)['ema_state_dict'],strict=True)
 pstate=parent.state_dict()
 assert set(pstate).issubset(common) and all(torch.equal(pstate[k],common[k]) for k in pstate)
 del cpu;gc.collect()
 init={'status':'PENDING_GPU_IDENTITY','parent_sha':sha(PARENT),'parent_keys':len(pstate),'parent_every_tensor_retained_exactly':True,'parent_parameter_hash':statehash(pstate),'common_state_hash':commonhash,'common_keys':len(common),'common_checkpoint_sha':sha(ROOT/'COMMON_INITIAL_STATE.pt'),'zero_adaLN_gate':True,'global_zero_projection':True,'spatial_zero_projection':True,'no_dropped_parent_keys':True}
 write(ROOT/'INITIALIZATION_AUDIT.json',init)
 results=[];batch=2
 # Unified batch trial: synthetic shape first, then actual full forward/backward and probes.
 try:
  parent=parent.cuda().eval();seed()
  with AccessGuard():
   x,y,_=Stream(Pairs('train')).next(batch);x=x.cuda()
   xx=torch.cat((x*2-1,x*2-1),1);t=torch.tensor([511.,789.],device='cuda')[:batch]
   with torch.no_grad():parent_out=parent.model.unet0(xx,t).cpu()
  parent=parent.cpu();torch.cuda.empty_cache()
  with AccessGuard() as guard:
   for mode in ('CONTROL','MED_G','MED_S'):
    print('PREFLIGHT_BEGIN',mode,batch,flush=True)
    results.append(test(mode,batch,common,parent_out,xx,t))
    write(ROOT/f'audits/PREFLIGHT_{mode}_B{batch}.json',results[-1])
   write(ROOT/'audits/PREFLIGHT_DATA_ACCESS.json',guard.report())
 except torch.cuda.OutOfMemoryError:
  write(ROOT/'audits/BATCH2_OOM.json',{'failure':traceback.format_exc(),'formal_started':False,'uniform_fallback':'batch=1 accumulation=2','discard_all_batch2_probe_results':True})
  raise # Queue stopped. Uniform batch1 readiness must be a separately recorded invocation.
 init.update({'status':'PASS','all_variant_step0_parent_identity':True,'active_zero_branch_max_diff':{r['variant']:r['step0_active_max_diff'] for r in results}});write(ROOT/'INITIALIZATION_AUDIT.json',init)
 config=json.loads((ROOT/'CONFIG.json').read_text());config['batch']=batch;config['accumulation']=1;config['status']='PREFLIGHT_PASS';write(ROOT/'CONFIG.json',config)
 write(ROOT/'PREFLIGHT_AUDIT.json',{'status':'PASS','results':results,'formal_probe_count':0,'three_groups_common_init_identical':True,'no_other_gpu_training':True,'topology':STAGES,'spatial_stages':SPATIAL})
 lines=['# Preflight report','PASS. 100 optimizer steps per variant; all discarded; formal runs start from COMMON_INITIAL_STATE.pt with fresh Adam/EMA/RNG.','Batch 2, accumulation 1. Parent disabled-branch identity exact; active zero branch tolerance 1e-6.','Global/spatial projections have zero gradients at the initial backward because official adaLN gate is also zero. Both have nonzero finite gradients at the second backward after the first gate update. This is expected nested-zero initialization, not a disconnected branch.']
 for r in results:lines.append(f"- {r['variant']}: {r['mean_sec_per_step']:.4f} sec/step; allocated {r['peak_allocated_GiB']:.3f} GiB; reserved {r['peak_reserved_GiB']:.3f} GiB; trainable {r['trainable_parameters']}")
 lines.append('Estimated training-only serial wall time: '+str(sum(r['mean_sec_per_step']*8000 for r in results)/3600)+' hours, plus validation/checkpoint time.')
 (ROOT/'PREFLIGHT_REPORT.md').write_text('\n\n'.join(lines))
 write(ROOT/'STATUS.json',{'state':'PREFLIGHT_PASS_FORMAL_NOT_STARTED'})
if __name__=='__main__':
 try:main()
 except Exception:
  write(ROOT/'PREFLIGHT_RETRY_FAILURE.json',{'traceback':traceback.format_exc(),'formal_training_started':False})
  write(ROOT/'STATUS.json',{'state':'PREFLIGHT_FAILED_QUEUE_STOPPED'})
  raise
