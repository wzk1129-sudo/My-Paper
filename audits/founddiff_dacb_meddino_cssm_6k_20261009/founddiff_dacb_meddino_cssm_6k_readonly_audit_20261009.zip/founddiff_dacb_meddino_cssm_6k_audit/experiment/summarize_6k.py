"""Saved-metric aggregation; no array access or inference."""
from pathlib import Path
import csv,json,numpy as np
R=Path(__file__).resolve().parent
MODES=('CONTROL','MED_G','MED_S');METRICS=('psnr','ssim','rmse_hu','mae_hu')
def rc(p):return list(csv.DictReader(p.open()))
def wc(p,rows):
 with p.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main():
 finals={m:json.loads((R/m/'FINAL_STATE.json').read_text()) for m in MODES}
 assert all(x['status']=='PASS' and x['optimizer_step']==6000 for x in finals.values())
 assert len({x['common_init_hash'] for x in finals.values()})==1 and len({x['stream_chain'] for x in finals.values()})==1
 history=[];delta=[];paired=[];off=[]
 for step in (0,2000,4000,6000):
  values={m:json.loads((R/m/f'EMA_FAST64_STEP_{step}_NORMAL.json').read_text()) for m in MODES}
  history.extend(values.values())
  slices={m:{int(x['slice_index']):x for x in rc(R/m/f'PER_SLICE_STEP_{step}_NORMAL.csv')} for m in MODES}
  assert len(slices['CONTROL'])==64 and all(set(x)==set(slices['CONTROL']) for x in slices.values())
  for a,b in (('MED_G','CONTROL'),('MED_S','MED_G'),('MED_S','CONTROL')):
   row={'step':step,'comparison':a+' - '+b,**{'delta_'+k:values[a][k]-values[b][k] for k in METRICS}}
   row['PSNR_improved_slice_fraction']=float(np.mean([float(slices[a][i]['psnr'])>float(slices[b][i]['psnr']) for i in slices[a]]));delta.append(row)
   for i in sorted(slices[a]):
    sa,sb=slices[a][i],slices[b][i];assert sa['sampling_seed']==sb['sampling_seed']
    paired.append({'step':step,'comparison':a+' - '+b,'slice_index':i,'sampling_seed':sa['sampling_seed'],**{'delta_'+k:float(sa[k])-float(sb[k]) for k in METRICS}})
 for m in ('MED_G','MED_S'):
  normal=json.loads((R/m/'EMA_FAST64_STEP_6000_NORMAL.json').read_text())
  for condition in (('MEDDINO_OFF','SPATIAL_OFF') if m=='MED_S' else ('MEDDINO_OFF',)):
   x=json.loads((R/m/f'EMA_FAST64_STEP_6000_{condition}.json').read_text())
   off.append({'variant':m,'step':6000,'condition':condition,**{k:x[k] for k in METRICS},**{'normal_minus_off_'+k:normal[k]-x[k] for k in METRICS}})
 wc(R/'VALIDATION_HISTORY.csv',history);wc(R/'PER_SLICE_DELTA.csv',paired);wc(R/'MATCHED_COMPARISONS.csv',delta);wc(R/'CONDITION_OFF_DIAGNOSTICS.csv',off)
 access={m:json.loads((R/m/'DATA_ACCESS_AUDIT.json').read_text()) for m in MODES};(R/'DATA_ACCESS_AUDIT.json').write_text(json.dumps(access,indent=2))
 d=next(x for x in delta if x['step']==6000 and x['comparison']=='MED_S - CONTROL')
 gains=[x for x in delta if x['step']==6000 and x['comparison'] in ('MED_G - CONTROL','MED_S - CONTROL')]
 classification='A. GO' if d['delta_psnr']>=.03 and d['PSNR_improved_slice_fraction']>=.6 else 'B. WEAK' if any(x['delta_psnr']>0 for x in gains) else 'C. NO-GO'
 lines=['# FoundDiff-DACB + MedDINO CSSM matched serial 6k',classification,'All three variants completed 6000 optimizer steps and stopped; no follow-up experiment.','## EMA L333-fast64','Step | Variant | PSNR dB | SSIM | RMSE HU | MAE HU','---|---|---|---|---|---']
 for x in history:lines.append(f"{x['step']} | {x['variant']} | {x['psnr']:.6f} | {x['ssim']:.9f} | {x['rmse_hu']:.6f} | {x['mae_hu']:.6f}")
 lines+=['## Strict same-step differences','Step | Comparison | ΔPSNR | ΔSSIM | ΔRMSE | ΔMAE | Improved slices','---|---|---|---|---|---|---']
 for x in delta:lines.append(f"{x['step']} | {x['comparison']} | {x['delta_psnr']:+.6f} | {x['delta_ssim']:+.9f} | {x['delta_rmse_hu']:+.6f} | {x['delta_mae_hu']:+.6f} | {x['PSNR_improved_slice_fraction']:.1%}")
 lines+=['## Resources','Variant | Trainable params | All params | Peak allocated GiB | Peak reserved GiB | Mean sec/step','---|---|---|---|---|---']
 for m,x in finals.items():lines.append(f"{m} | {x['trainable_parameters']} | {x['all_parameters']} | {x['peak_allocated_GiB']:.3f} | {x['peak_reserved_GiB']:.3f} | {x['mean_sec_per_step']:.4f}")
 lines+=['Common initialization hash: '+finals['CONTROL']['common_init_hash'],'All 6000 augmented batch/timestep/noise hashes match CONTROL; final chain: '+finals['CONTROL']['stream_chain'],'Checkpoint SHA256 and CPU reload audits saved per checkpoint. NaN/Inf/overflow/optimizer skip zero; frozen MedDINO hashes unchanged; L506/external memory/neighbor NDCT/blocked accesses zero.']
 lines+=['## Condition-off diagnostics','Variant | Condition | Normal − Off PSNR | Normal − Off SSIM | Normal − Off RMSE | Normal − Off MAE','---|---|---|---|---|---']
 for x in off:lines.append(f"{x['variant']} | {x['condition']} | {x['normal_minus_off_psnr']:+.6f} | {x['normal_minus_off_ssim']:+.9f} | {x['normal_minus_off_rmse_hu']:+.6f} | {x['normal_minus_off_mae_hu']:+.6f}")
 lines+=['## Activity','Nonzero branch gradients and condition-off differences establish branch participation; they do not establish reconstruction improvement. CONDITION_ACTIVITY_STEP_* and preflight two-backward gradient audits record participation.','## Recommendation','Med-S meets +0.03 dB and >=60% slice criterion; consider a separately authorized Full-L333 validation.' if classification=='A. GO' else 'Small or unstable evidence; no automatic next experiment.' if classification=='B. WEAK' else 'No effective matched reconstruction gain.','## Limits','Single matched seed and Fast64 screening. This CT adaptation retains the old restored RLEB time MLP and removes original DA-CLIP/dose paths. It is not the original full FoundDiff protocol. No medical-image visual review is claimed.']
 (R/'FINAL_REPORT.md').write_text('\n\n'.join(lines)+'\n')
 (R/'PIPELINE_COMPLETE.json').write_text(json.dumps({'status':'PASS','classification':classification,'variants':list(MODES),'steps_each':6000,'no_followup_started':True},indent=2))
 (R/'STATUS.json').write_text(json.dumps({'state':'COMPLETE','classification':classification,'steps_each':6000},indent=2))
 print(classification,flush=True)
if __name__=='__main__':main()
