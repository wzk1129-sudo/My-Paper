"""Strict serial matched training from common parent; no retries or protocol changes."""
from pathlib import Path
import sys,json,time,copy,gc,traceback,hashlib,os,subprocess
import numpy as np
import torch
from model_cssm import *
from protocol_cssm import *
VARIANTS=('CONTROL','MED_G','MED_S')
def assert_equal(a,b):
 if torch.is_tensor(a):
  assert torch.is_tensor(b) and a.dtype==b.dtype and a.shape==b.shape and torch.equal(a.detach().cpu(),b.detach().cpu())
 elif isinstance(a,np.ndarray):assert isinstance(b,np.ndarray) and np.array_equal(a,b)
 elif isinstance(a,dict):
  assert a.keys()==b.keys()
  for k in a:assert_equal(a[k],b[k])
 elif isinstance(a,(tuple,list)):
  assert type(a)==type(b) and len(a)==len(b)
  for x,y in zip(a,b):assert_equal(x,y)
 else:assert a==b,(a,b)
def finite(model):
 assert all(torch.isfinite(p).all() for p in model.parameters())
def check_sources():
 pins=json.loads((ROOT/'SOURCE_MANIFEST_6K.json').read_text())
 for p,h in pins.items():assert sha(p)==h,'Source changed: '+p
def saveck(path,payload):
 tmp=path.with_suffix('.tmp');torch.save(payload,tmp);os.replace(tmp,path)
 ck=torch.load(path,map_location='cpu',weights_only=False)
 assert ck['step']==payload['step'] and statehash(ck['model'])==statehash(payload['model'])
 assert statehash(ck['ema'])==statehash(payload['ema']) and ck['ema_updates']==ck['step']
 audit={'status':'PASS','step':ck['step'],'sha256':sha(path),'cpu_reload':True,'model_hash':statehash(ck['model']),'ema_hash':statehash(ck['ema']),'has_full_optimizer_RNG_stream':all(k in ck for k in ('optimizer','rng','stream','noise_generator'))}
 write(path.with_suffix('.audit.json'),audit)
 return audit
def cpu_state(m):return {n:t.detach().cpu().clone() for n,t in m.state_dict().items()}
def grads(model):
 groups={}
 for n,p in model.named_parameters():
  if not p.requires_grad:assert p.grad is None;continue
  assert p.grad is not None and torch.isfinite(p.grad).all(),n
  g='global_projection' if 'global_projection' in n else 'spatial' if 'spatial_projections' in n else 'dacb' if '.dacb.' in n else 'main'
  groups[g]=groups.get(g,0.)+float(p.grad.detach().square().sum())
 return {k:v**.5 for k,v in groups.items()}
def gpu_gate():
 raw=subprocess.check_output(['/usr/lib/wsl/lib/nvidia-smi','--query-compute-apps=pid,used_memory','--format=csv,noheader,nounits'],text=True).strip()
 for line in raw.splitlines():
  pid=line.split(',')[0].strip()
  assert pid==str(os.getpid()),'Other GPU process present; do not compete: '+line
 return raw
def run(mode):
 assert mode in VARIANTS;check_sources();gpu_gate();config=json.loads((ROOT/'CONFIG_6K.json').read_text())
 assert config['steps']==6000 and config['status']=='PREFLIGHT_PASS'
 run=ROOT/mode
 resume=mode=='CONTROL'
 if resume:
  transition=json.loads((ROOT/'TRANSITION_6K_CHECKPOINT_AUDIT.json').read_text())
  assert transition['status']=='PASS' and transition['checkpoint_step']==1000
  assert run.exists() and not (run/'RESUME_AUDIT_6K.json').exists()
 else:
  assert not run.exists(),'Refuse to overwrite or duplicate existing run';run.mkdir();(run/'checkpoints').mkdir()
 bundle=torch.load(ROOT/'COMMON_INITIAL_STATE.pt',map_location='cpu',weights_only=False);common=bundle['common_state']
 model=build(mode,common).cuda();assert statehash(common_state(model))==bundle['hash']
 initial_hash=statehash(model.state_dict());u=model.model.unet0
 condition_initial_hash=None if mode=="CONTROL" else statehash({n:t for n,t in model.state_dict().items() if any("."+k+"." in n for k in ("layer_adapters","fusion","global_projection"))})
 if mode=="MED_S":
  assert condition_initial_hash==json.loads((ROOT/"MED_G/FRESH_START_AUDIT.json").read_text())["global_condition_initial_hash"]
 frozen_hash=med_state_hash(model)
 ema=copy.deepcopy(model).eval().requires_grad_(False);ema_updates=0
 optimizer=torch.optim.Adam([p for p in model.parameters() if p.requires_grad],lr=2e-4,betas=(.9,.99),weight_decay=1e-9)
 assert not optimizer.state;seed()
 noisegen=torch.Generator(device='cuda').manual_seed(20260829)
 pairs=Pairs('train');stream=Stream(pairs);batch=config['batch'];accum=config['accumulation'];assert batch*accum==2
 if not resume:write(run/'FRESH_START_AUDIT.json',{'status':'PASS','common_hash':bundle['hash'],'initial_full_hash':initial_hash,'global_condition_initial_hash':condition_initial_hash,'fresh_Adam_empty_state':True,'seed':20260829,'manifest_hash':pairs.manifest_sha,'no_previous_variant_checkpoint_loaded':True,'MedDINO_parameter_hash':frozen_hash})
 reference=[]
 if mode!='CONTROL':
  reference=[json.loads(s) for s in (ROOT/'CONTROL/TRAIN_STREAM_6K.jsonl').read_text().splitlines()]
  assert len(reference)==6000
 history=[];timing=[];chain='0'*64;guards=None;start_step=0;prefix_records=[];prefix_logs=[];prefix_access=None
 if resume:
  import csv
  checkpoint=run/'checkpoints/step_1000.pt'
  assert sha(checkpoint)==transition['checkpoint_sha256']
  ck=torch.load(checkpoint,map_location='cpu',weights_only=False)
  assert ck['step']==1000 and ck['variant']=='CONTROL' and ck['ema_updates']==1000
  assert ck['common_init_hash']==bundle['hash']
  assert {k for k in config if config[k]!=ck['config'][k]}=={'steps','validation_steps'}
  model.load_state_dict(ck['model'],strict=True);ema.load_state_dict(ck['ema'],strict=True)
  optimizer.load_state_dict(ck['optimizer'])
  assert_equal(optimizer.state_dict(),ck['optimizer'])
  assert statehash(model.state_dict())==statehash(ck['model']) and statehash(ema.state_dict())==statehash(ck['ema'])
  st=ck['stream'];assert st['manifest']==pairs.manifest_sha
  stream.rng.set_state(st['rng']);stream.order=st['permutation'].copy();stream.cursor=st['cursor'];stream.epoch=st['epoch']
  assert_equal(stream.state_dict(),st)
  noisegen.set_state(ck['noise_generator']);assert torch.equal(noisegen.get_state(),ck['noise_generator'])
  prefix_records=[json.loads(x) for x in (run/'TRAIN_STREAM.jsonl').read_text().splitlines() if json.loads(x)['step']<=1000]
  prefix_logs=[json.loads(x) for x in (run/'TRAIN_LOG.jsonl').read_text().splitlines() if json.loads(x)['step']<=1000]
  assert [x['step'] for x in prefix_records]==list(range(1,1001)) and len(prefix_logs)==1000
  assert prefix_records[-1]['chain']==ck['stream_chain']
  chain=ck['stream_chain'];ema_updates=ck['ema_updates'];start_step=ck['step'];timing=[x['seconds'] for x in prefix_logs]
  history=[{k:(float(v) if k in METRICS+('validation_seconds',) else int(v) if k in ('step','slices') else v) for k,v in row.items()} for row in csv.DictReader((run/'VALIDATION_HISTORY.csv').open())]
  assert [x['step'] for x in history]==[0]
  prefix_access={p:{'LDCT':0,'NDCT_center_target':0} for p in COUNTS};prefix_access['L333']={'LDCT':64,'NDCT_center_target':64}
  for record in prefix_records:
   for realization in record['realizations']:
    for sample in realization['samples']:
     for key in ('LDCT','NDCT_center_target'):prefix_access[sample['patient_id']][key]+=1
  assert med_state_hash(model)==med_state_hash(ema)==ck['MedDINO_hash']==frozen_hash
  torch.set_rng_state(ck['rng']['torch']);torch.cuda.set_rng_state_all(ck['rng']['cuda']);np.random.set_state(ck['rng']['numpy'])
  assert torch.equal(torch.get_rng_state(),ck['rng']['torch'])
  assert all(torch.equal(a,b) for a,b in zip(torch.cuda.get_rng_state_all(),ck['rng']['cuda']))
  assert_equal(np.random.get_state(),ck['rng']['numpy'])
  write(run/'RESUME_AUDIT_6K.json',{'status':'PASS','step':1000,'checkpoint_sha256':sha(checkpoint),'model_exact':True,'EMA_exact':True,'Adam_exact':True,'Adam_reset':False,'stream_exact':True,'noise_generator_exact':True,'default_RNG_exact':True,'chain':chain,'allowed_config_changes':['steps','validation_steps'],'discard_unsaved_steps_then_replay_from_full_checkpoint':True})
  del ck;gc.collect()
  print('EXACT_CONTROL_RESUME_STEP_1000',flush=True)
 try:
  with AccessGuard() as guard:
   guards=guard
   if prefix_access is not None:guard.counts=prefix_access
   summary,rows=(history[0],None) if resume else validate(ema,0,run)
   if mode!='CONTROL':
    cr=json.loads((ROOT/'CONTROL/EMA_FAST64_STEP_0_NORMAL.json').read_text())
    assert all(summary[k]==cr[k] for k in METRICS),'Step0 metrics differ from Control'
   if not resume:history.append(summary);csvwrite(run/'VALIDATION_HISTORY.csv',history)
   write(ROOT/'STATUS.json',{'state':'TRAINING','variant':mode,'step':start_step,'maximum':6000})
   torch.cuda.reset_peak_memory_stats();started=time.perf_counter()
   with (run/'TRAIN_STREAM_6K.jsonl').open('x',buffering=1) as streamlog,(run/'TRAIN_LOG_6K.jsonl').open('x',buffering=1) as log:
    for row in prefix_records:streamlog.write(json.dumps(row,separators=(',',':'))+'\n')
    for row in prefix_logs:log.write(json.dumps(row)+'\n')
    for step in range(start_step+1,6001):
     if step%100==1:check_sources();gpu_gate()
     t0=time.perf_counter();model.train();optimizer.zero_grad(set_to_none=True);lossvalue=0.;realizations=[]
     for micro in range(accum):
      x,y,metadata=stream.next(batch);x=x.cuda();y=y.cuda()
      tt=torch.randint(0,1000,(batch,),device='cuda',generator=noisegen);noise=torch.randn(x.shape,device='cuda',generator=noisegen)
      h=hashlib.sha256()
      for t in (x,y,tt,noise):h.update(t.detach().cpu().contiguous().numpy().tobytes())
      realizations.append({'micro':micro,'samples':metadata,'timestep':tt.tolist(),'tensor_sha256':h.hexdigest()})
      u.set_context(x)
      loss=model.p_losses([y*2-1,x*2-1],tt,noise)[0]/accum;assert torch.isfinite(loss);loss.backward();lossvalue+=float(loss.detach());u.clear_context()
     g=grads(model)
     norm=torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],1.,error_if_nonfinite=True)
     optimizer.step();finite(model)
     with torch.no_grad():
      for ep,p in zip(ema.parameters(),model.parameters()):
       if p.requires_grad:ep.mul_(.995).add_(p,alpha=.005)
       else:ep.copy_(p)
      for eb,b in zip(ema.buffers(),model.buffers()):eb.copy_(b)
     ema_updates+=1
     record={'step':step,'realizations':realizations}
     token=hashlib.sha256(json.dumps(record,sort_keys=True,separators=(',',':')).encode()).hexdigest()
     chain=hashlib.sha256((chain+token).encode()).hexdigest();record.update({'step_hash':token,'chain':chain})
     if reference:assert record==reference[step-1],f'Data/noise stream mismatch at {step}'
     streamlog.write(json.dumps(record,separators=(',',':'))+'\n')
     if resume and step==1001:
      old=[json.loads(x) for x in (run/'TRAIN_STREAM.jsonl').read_text().splitlines() if json.loads(x)['step']==1001]
      if old:assert record==old[0],'First resumed batch differs from original unsaved next batch'
      write(run/'FIRST_RESUMED_BATCH_AUDIT.json',{'status':'PASS','step':step,'stream_hash':token,'old_unsaved_batch_available':bool(old),'exact_match_if_available':True,'finite_loss_grad_parameters':True,'Adam_reset':False})
      print('FIRST_RESUMED_BATCH_PASS',flush=True)
     torch.cuda.synchronize();secs=time.perf_counter()-t0;timing.append(secs)
     allocated=torch.cuda.max_memory_allocated()/2**30;reserved=torch.cuda.max_memory_reserved()/2**30
     row={'step':step,'loss':lossvalue,'grad_norm_pre_clip':float(norm),'seconds':secs,'peak_allocated_GiB':allocated,'peak_reserved_GiB':reserved,'gradient_groups':g,'stream_hash':token,'NaN_Inf_overflow_optimizer_skip':0}
     log.write(json.dumps(row)+'\n')
     if step%100==0:
      print(mode,json.dumps(row),flush=True)
      write(run/'STATUS.json',{'state':'TRAINING','variant':mode,**row});write(ROOT/'STATUS.json',{'state':'TRAINING','variant':mode,**row})
      write(run/'DATA_ACCESS_AUDIT.json',guard.report())
     if step%1000==0:
      assert med_state_hash(model)==frozen_hash and med_state_hash(ema)==frozen_hash
      payload={'step':step,'variant':mode,'model':cpu_state(model),'ema':cpu_state(ema),'optimizer':optimizer.state_dict(),'ema_updates':ema_updates,'rng':{'torch':torch.get_rng_state(),'cuda':torch.cuda.get_rng_state_all(),'numpy':np.random.get_state()},'noise_generator':noisegen.get_state(),'stream':stream.state_dict(),'stream_chain':chain,'config':config,'source_manifest':json.loads((ROOT/'SOURCE_MANIFEST_6K.json').read_text()),'common_init_hash':bundle['hash'],'MedDINO_hash':frozen_hash}
      ck=run/'checkpoints'/f'step_{step}.pt';audit=saveck(ck,payload);del payload;gc.collect()
     if step%2000==0:
      summary,rows=validate(ema,step,run);history.append(summary);csvwrite(run/'VALIDATION_HISTORY.csv',history)
      print('EMA_VALIDATION',json.dumps(summary),flush=True)
      write(run/'DATA_ACCESS_AUDIT.json',guard.report())
   if mode!='CONTROL':
    off,_=validate(ema,6000,run,'MEDDINO_OFF')
    if mode=='MED_S':validate(ema,6000,run,'SPATIAL_OFF')
   check_sources();finite(model);assert ema_updates==6000 and med_state_hash(model)==frozen_hash and med_state_hash(ema)==frozen_hash
   access=guard.report();assert access['blocked_attempts']==0
   final={'status':'PASS','variant':mode,'optimizer_step':6000,'EMA_updates':ema_updates,'common_init_hash':bundle['hash'],'final_model_hash':statehash(model.state_dict()),'MedDINO_before_after_equal':True,'MedDINO_hash':frozen_hash,'stream_chain':chain,'stream_matches_CONTROL_all6000':True if mode!='CONTROL' else 'canonical reference','NaN_Inf_overflow_optimizer_skip':0,'mean_sec_per_step':float(np.mean(timing)),'median_sec_per_step':float(np.median(timing)),'peak_allocated_GiB':max([torch.cuda.max_memory_allocated()/2**30]+[x['peak_allocated_GiB'] for x in prefix_logs]),'peak_reserved_GiB':max([torch.cuda.max_memory_reserved()/2**30]+[x['peak_reserved_GiB'] for x in prefix_logs]),'trainable_parameters':sum(p.numel() for p in model.parameters() if p.requires_grad),'all_parameters':sum(p.numel() for p in model.parameters()),'data_access':access,'final_checkpoint_sha256':sha(run/'checkpoints/step_6000.pt')}
   write(run/'FINAL_STATE.json',final);write(run/'DATA_ACCESS_AUDIT.json',access);write(run/'STATUS.json',{'state':'COMPLETE','step':6000})
   print('VARIANT_COMPLETE',mode,flush=True)
 except Exception:
  write(run/'TRAIN_FAILURE.json',{'variant':mode,'step':locals().get('step',0),'traceback':traceback.format_exc(),'data_access':None if guards is None else guards.report()})
  write(ROOT/'STATUS.json',{'state':'FAILED_QUEUE_STOPPED','variant':mode,'step':locals().get('step',0)})
  raise
if __name__=='__main__':run(sys.argv[1])
