#!/usr/bin/env bash
set -euo pipefail
cd /home/xujian/projects/CoreDiff
export CUDA_HOME=/usr/local/cuda-12.8
export PATH=/usr/local/cuda-12.8/bin:/home/xujian/miniconda3/envs/rddm_cvpr2024/bin:/usr/bin:/bin
export MAX_JOBS=1 TORCH_CUDA_ARCH_LIST=8.6
export TORCH_EXTENSIONS_DIR=/home/xujian/projects/CoreDiff/experiments/founddiff_dacb_meddino_cssm_screen_20261008/runtime/extensions
export PYTHONDONTWRITEBYTECODE=1
/home/xujian/miniconda3/envs/flexict/bin/python -u experiments/founddiff_dacb_meddino_cssm_screen_20261008/build_kernel.py > experiments/founddiff_dacb_meddino_cssm_screen_20261008/logs/kernel_build_retry_existing_ninja.log 2>&1
