#!/usr/bin/env bash
set -euo pipefail
cd /home/xujian/projects/CoreDiff
export PYTHONDONTWRITEBYTECODE=1 CUDA_VISIBLE_DEVICES=0 CUBLAS_WORKSPACE_CONFIG=:4096:8
export OMP_NUM_THREADS=2 MKL_NUM_THREADS=2
/home/xujian/miniconda3/envs/flexict/bin/python -u experiments/founddiff_dacb_meddino_cssm_screen_20261008/pipeline_6k.py > experiments/founddiff_dacb_meddino_cssm_screen_20261008/logs/pipeline_6k.log 2>&1
