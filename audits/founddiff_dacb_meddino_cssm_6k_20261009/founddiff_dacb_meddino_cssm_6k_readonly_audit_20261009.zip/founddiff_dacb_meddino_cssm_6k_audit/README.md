# FoundDiff DACB + MedDINO CSSM 6k 只读审计资料包

日期：2026-10-09（Asia/Shanghai）。

## 审计范围
CONTROL → MED_G → MED_S，三组各6000 optimizer steps；固定0/2k/4k/6k L333-fast64 EMA。
本轮只读源码、现有日志和现有 checkpoint 的 CPU 标量统计，未执行模型前向/反向、训练、采样或 L333 验证。
没有访问医学数组、L506 或外部参考数据；没有改动原实验源码或结果。

## 文件布局
- experiment/：实际运行源码、6k有效配置、历史8k配置、初始化/迁移/预检审计、现有训练数值日志、条件活动记录、条件关闭诊断及原始最终报告。
- upstream/FoundDiff/：官方 DADiff.py / emamba2.py 实现参考。
- upstream/MedDINOv3/：manifest 已固定的 MedDINO/DINOv3 Python 源码和可用许可证。
- reference/V1/：V1 的 MedDINO 输入/融合实现参考。
- reference/parent_protocol/：父实验冻结数据/评价协议参考。
- audit/：本轮审计结论、参数更新统计、训练梯度摘要、条件RMS汇总、optimizer组、随机流一致性证明、审计访问范围。
- PACKAGE_SOURCE_INDEX.json：每份原始文本对应源路径、角色、SHA256、大小和字节一致性。
- PACKAGE_EXCLUSIONS.json：明确排除的文件类别。
- PACKAGE_MANIFEST.json：最终ZIP各项内容的SHA256及大小。

## 有效配置
实际6k训练使用 experiment/CONFIG_6K.json、train_cssm_6k.py、pipeline_6k.py、summarize_6k.py 和 SOURCE_MANIFEST_6K.json。
旧 CONFIG.json/8k脚本保留作历史证据；CONTROL最初1k由原8k脚本运行，之后通过完整 model/EMA/Adam/RNG/stream checkpoint 精确续接。
G/S始终独立从公共父初始化开始，未继承前组训练结果。

## 资料保真与省略
源码文件逐字节复制，未重写导入、路径或运行逻辑。许多路径绑定远程WSL，本包用于审核，不是开箱即跑的新实验。
不包含 .pt/.pth/.safetensors、COMMON_INITIAL_STATE 张量、医学 .npy/.npz、图片、编译 .so/.o、大缓存。
checkpoint_audit_metadata/只含JSON审计元数据和哈希，绝不包含checkpoint张量。
逐切片CSV、Fast64切片清单、患者/切片/augmentation原始训练流清单未导出；保留聚合指标和不含切片身份的随机流哈希证明。
训练数值JSONL含step/loss/梯度范数/显存/耗时/hash，不含医学数组或切片身份。
审计代理完整请求/响应trace只保留在远程新审计目录的.aris/traces/，不进入ZIP或GitHub。

## 统计口径
- global/spatial投影初始化为零，因此0→6k绝对更新可以直接计算。
- shared-core初始张量存在公共初始化；比较common→6k。
- adapters/fusion的初始私有张量未保存在完整step0 checkpoint；仅报告1k→6k更新，不能冒充0→6k。
- gate_msa/gate_mlp行的W/bias RMS是参数代理，不是实际gate(t)幅度。实际门控输出未保存，禁止推算成已测量值。
- group梯度范数比依赖参数量和分组，不能作为精确相对功能强度。
- off诊断是同一已训练模型内部消融，不能替代跨实验Control对照。

## 重新验证
任何需要新网络执行才能证明的问题，只列在audit/VERIFICATION_PLAN_NOT_EXECUTED.md，本轮不执行。
同模型家族fresh-agent意见标记 provisional；哈希、记录一致性和CPU标量统计属于可复核事实。

## 来源与许可
保留实际上游源码、出处和已有许可证。FoundDiff官方checkout未发现根LICENSE文件；本包不主张所有上游代码为MIT或授予额外许可。
MedDINO/DINOv3/Mamba的上游使用限制以包内对应许可证为准。本资料提交到用户既有私有GitHub仓库审核，不上传医学数据。
