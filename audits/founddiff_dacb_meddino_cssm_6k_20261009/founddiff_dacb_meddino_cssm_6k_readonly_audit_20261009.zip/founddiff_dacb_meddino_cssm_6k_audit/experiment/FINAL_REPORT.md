# FoundDiff-DACB + MedDINO CSSM matched serial 6k

C. NO-GO

All three variants completed 6000 optimizer steps and stopped; no follow-up experiment.

## EMA L333-fast64

Step | Variant | PSNR dB | SSIM | RMSE HU | MAE HU

---|---|---|---|---|---

0 | CONTROL | 40.655957 | 0.946080809 | 18.654227 | 12.187841

0 | MED_G | 40.655957 | 0.946080809 | 18.654227 | 12.187841

0 | MED_S | 40.655957 | 0.946080809 | 18.654227 | 12.187841

2000 | CONTROL | 40.690991 | 0.946720705 | 18.578552 | 12.144088

2000 | MED_G | 40.691082 | 0.946722789 | 18.578340 | 12.143882

2000 | MED_S | 40.692227 | 0.946731688 | 18.576002 | 12.142939

4000 | CONTROL | 40.684509 | 0.946659265 | 18.592204 | 12.153070

4000 | MED_G | 40.685606 | 0.946684820 | 18.589581 | 12.150478

4000 | MED_S | 40.687657 | 0.946703846 | 18.585363 | 12.150002

6000 | CONTROL | 40.684519 | 0.946670206 | 18.591804 | 12.157335

6000 | MED_G | 40.678648 | 0.946619591 | 18.604376 | 12.162352

6000 | MED_S | 40.680749 | 0.946648663 | 18.599658 | 12.157785

## Strict same-step differences

Step | Comparison | ΔPSNR | ΔSSIM | ΔRMSE | ΔMAE | Improved slices

---|---|---|---|---|---|---

0 | MED_G - CONTROL | +0.000000 | +0.000000000 | +0.000000 | +0.000000 | 0.0%

0 | MED_S - MED_G | +0.000000 | +0.000000000 | +0.000000 | +0.000000 | 0.0%

0 | MED_S - CONTROL | +0.000000 | +0.000000000 | +0.000000 | +0.000000 | 0.0%

2000 | MED_G - CONTROL | +0.000091 | +0.000002085 | -0.000211 | -0.000206 | 78.1%

2000 | MED_S - MED_G | +0.001145 | +0.000008899 | -0.002338 | -0.000942 | 87.5%

2000 | MED_S - CONTROL | +0.001236 | +0.000010984 | -0.002550 | -0.001149 | 92.2%

4000 | MED_G - CONTROL | +0.001097 | +0.000025555 | -0.002622 | -0.002592 | 71.9%

4000 | MED_S - MED_G | +0.002052 | +0.000019027 | -0.004218 | -0.000476 | 81.2%

4000 | MED_S - CONTROL | +0.003149 | +0.000044582 | -0.006840 | -0.003068 | 93.8%

6000 | MED_G - CONTROL | -0.005871 | -0.000050615 | +0.012572 | +0.005016 | 0.0%

6000 | MED_S - MED_G | +0.002101 | +0.000029072 | -0.004718 | -0.004566 | 82.8%

6000 | MED_S - CONTROL | -0.003770 | -0.000021543 | +0.007854 | +0.000450 | 4.7%

## Resources

Variant | Trainable params | All params | Peak allocated GiB | Peak reserved GiB | Mean sec/step

---|---|---|---|---|---

CONTROL | 26227263 | 26227263 | 21.693 | 22.727 | 1.1136

MED_G | 26490047 | 112132031 | 22.366 | 23.285 | 1.7110

MED_S | 26721215 | 112363199 | 22.528 | 23.463 | 1.4564

Common initialization hash: e303a436cd762d1ec29d48795ec8b2c757ae99ecf3ef15d1d81d511620d822ab

All 6000 augmented batch/timestep/noise hashes match CONTROL; final chain: 3a1f2797bcd9aa788a78a228faea70db36c3ebbbdaa39166f98980ae73db213d

Checkpoint SHA256 and CPU reload audits saved per checkpoint. NaN/Inf/overflow/optimizer skip zero; frozen MedDINO hashes unchanged; L506/external memory/neighbor NDCT/blocked accesses zero.

## Condition-off diagnostics

Variant | Condition | Normal − Off PSNR | Normal − Off SSIM | Normal − Off RMSE | Normal − Off MAE

---|---|---|---|---|---

MED_G | MEDDINO_OFF | -0.000017 | -0.000000226 | +0.000037 | +0.000011

MED_S | MEDDINO_OFF | +0.000122 | +0.000000901 | -0.000259 | -0.000042

MED_S | SPATIAL_OFF | +0.000134 | +0.000001082 | -0.000284 | -0.000056

## Activity

Nonzero branch gradients and condition-off differences establish branch participation; they do not establish reconstruction improvement. CONDITION_ACTIVITY_STEP_* and preflight two-backward gradient audits record participation.

## Recommendation

No effective matched reconstruction gain.

## Limits

Single matched seed and Fast64 screening. This CT adaptation retains the old restored RLEB time MLP and removes original DA-CLIP/dose paths. It is not the original full FoundDiff protocol. No medical-image visual review is claimed.
