"""User-authorized cap change; only stop our verified old process at audited full 1k."""
from pathlib import Path
import os,json,time,signal,subprocess,hashlib,traceback,datetime
R=Path(__file__).resolve().parent
OLD_PIPELINE=375920
OLD_TRAIN=375923
def write(n,x):
 p=R/n;t=p.with_suffix('.tmp');t.write_text(json.dumps(x,indent=2));os.replace(t,p)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def cmd(pid):return Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\0',b' ').decode()
def verified():
 assert str(R/'train_cssm.py')+' CONTROL' in cmd(OLD_TRAIN)
 assert 'experiments/founddiff_dacb_meddino_cssm_screen_20261008/pipeline.py' in cmd(OLD_PIPELINE)
 assert int(Path(f'/proc/{OLD_TRAIN}/stat').read_text().split()[3])==OLD_PIPELINE
def state(pid):
 p=Path(f'/proc/{pid}/status')
 if not p.exists():return 'gone'
 return next(x for x in p.read_text().splitlines() if x.startswith('State:'))
def gpu():
 return subprocess.check_output(['/usr/lib/wsl/lib/nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip()
def main():
 assert not (R/'TRANSITION_6K_CHECKPOINT_AUDIT.json').exists()
 verified()
 write('TRANSITION_6K_STATUS.json',{'state':'WAITING_FOR_FULL_STEP_1000','old_train_pid':OLD_TRAIN,'new_cap_each':6000,'validation_steps':[0,2000,4000,6000]})
 deadline=time.monotonic()+2400
 audit=R/'CONTROL/checkpoints/step_1000.audit.json'
 while not audit.exists():
  verified();assert time.monotonic()<deadline,'Checkpoint wait timeout'
  assert not (R/'CONTROL/TRAIN_FAILURE.json').exists(),'Training failed before complete checkpoint'
  time.sleep(.2)
 verified()
 a=json.loads(audit.read_text());assert a['status']=='PASS' and a['step']==1000 and a['cpu_reload'] and a['has_full_optimizer_RNG_stream']
 # Stop original coordinator before child, so no new variant can start.
 os.kill(OLD_PIPELINE,signal.SIGSTOP);os.kill(OLD_TRAIN,signal.SIGSTOP)
 time.sleep(.3)
 assert 'T' in state(OLD_PIPELINE) and 'T' in state(OLD_TRAIN)
 print('ORIGINAL_PROCESSES_FROZEN_AT_AUDITED_CHECKPOINT',flush=True)
 checkpoint=R/'CONTROL/checkpoints/step_1000.pt'
 assert sha(checkpoint)==a['sha256']
 import torch
 ck=torch.load(checkpoint,map_location='cpu',weights_only=False)
 assert ck['step']==ck['ema_updates']==1000 and ck['variant']=='CONTROL'
 assert all(k in ck for k in ('model','ema','optimizer','rng','noise_generator','stream','stream_chain'))
 assert ck['optimizer']['state'] and all(int(v['step'])==1000 for v in ck['optimizer']['state'].values())
 for p,h in ck['source_manifest'].items():assert sha(p)==h,'Frozen original source changed: '+p
 configs=json.loads((R/'CONFIG_6K.json').read_text())
 assert {k for k in configs if configs[k]!=ck['config'][k]}=={'steps','validation_steps'}
 assert configs['steps']==6000 and configs['validation_steps']==[0,2000,4000,6000]
 stream=[json.loads(x) for x in (R/'CONTROL/TRAIN_STREAM.jsonl').read_text().splitlines()]
 assert len(stream)>=1000 and stream[999]['chain']==ck['stream_chain']
 discarded=[x['step'] for x in stream if x['step']>1000]
 transition={'status':'PASS','reason':'Latest user changes all variants from 8k to 6k','checkpoint_step':1000,'checkpoint_sha256':a['sha256'],'cpu_reload':True,'full_model_EMA_Adam_RNG_stream_present':True,'Adam_reset':False,'original_model_sources_unchanged':True,'config_only_differences':['steps','validation_steps'],'old_pids':[OLD_PIPELINE,OLD_TRAIN],'completed_unsaved_steps_replayed_from_checkpoint':discarded,'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 write('TRANSITION_6K_CHECKPOINT_AUDIT.json',transition)
 del ck
 # Exact target PIDs and command lines verified; no other task is affected.
 verified()
 os.kill(OLD_TRAIN,signal.SIGKILL);os.kill(OLD_PIPELINE,signal.SIGKILL)
 for _ in range(150):
  if not gpu():break
  time.sleep(.2)
 assert not gpu(),'GPU not released; do not launch new process'
 write('TRANSITION_6K_STATUS.json',{'state':'COMPLETE_EXACT_1K_HANDOFF','new_cap_each':6000,'no_from_zero_restart':True})
 print('LAUNCH_SERIAL_6K_EXACT_CONTROL_RESUME',flush=True)
 os.execv('/bin/bash',['bash',str(R/'launch_serial_6k.sh')])
if __name__=='__main__':
 try:main()
 except Exception:
  write('TRANSITION_6K_FAILURE.json',{'traceback':traceback.format_exc(),'old_parent_state':state(OLD_PIPELINE),'old_train_state':state(OLD_TRAIN),'no_automatic_restart':True})
  raise
