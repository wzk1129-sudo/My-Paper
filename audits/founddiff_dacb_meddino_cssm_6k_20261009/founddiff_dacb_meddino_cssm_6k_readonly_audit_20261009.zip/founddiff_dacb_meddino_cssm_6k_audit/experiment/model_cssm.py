"""Parent RLEB/time/head retained; official zero-gated Mamba updates at official positions."""
import sys,hashlib,json,copy
from pathlib import Path
import torch
from torch import nn
from torch.nn import functional as F
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'vendor'));sys.path.insert(0,str(ROOT/'runtime/extensions'))
from parent_rleb import Unet,build_baseline
from official_blocks import Mamba_block
from med_loader import official_med,MEAN_HU,STD_HU,MED_SHA
PARENT=Path('/home/xujian/projects/CoreDiff/experiments/founddiff_table_v_20260921/rddm_rleb/mayo2016_smallset_v1/runs/FoundDiff_RDDM_RLEB_Mayo2016_smallset_v1_60k_20260921/checkpoints/step_60000.pt')
STAGES={'E0':(64,4,512),'E1':(64,8,256),'E2':(128,16,128),'E3':(256,32,64),'MID':(512,32,64),'D0':(512,32,64),'D1':(256,16,128),'D2':(128,8,256),'D3':(64,4,512)}
SPATIAL=('E2','MID','D1')
def statehash(state):
 h=hashlib.sha256()
 for n,t in sorted(state.items()):
  h.update(n.encode());h.update(str(t.dtype).encode());h.update(str(tuple(t.shape)).encode());h.update(t.detach().cpu().contiguous().reshape(-1).view(torch.uint8).numpy().tobytes())
 return h.hexdigest()
def rms(x):return float(x.detach().float().square().mean().sqrt())
class CSSMUnet(Unet):
 def __init__(self,mode):
  super().__init__(dim=64,dim_mults=(1,2,4,8),channels=1,condition=True)
  assert mode in ('CONTROL','MED_G','MED_S');self.mode=mode
  self.dacb=nn.ModuleDict({s:Mamba_block(c,n,2.,0.,cross=False,time_emb_dim=256) for s,(c,n,k) in STAGES.items()})
  for block in self.dacb.values():block.mamba.d_inner=int(block.mamba.x_proj_weight.shape[-1]) # exact official scan channel dimension, no hardcoded width
  self._c=None;self._spatial={};self.branch_off=False;self.spatial_off=False;self.meddino_off=False
  self.extract_calls=0;self.forward_calls=0;self.record=False;self.activity=[]
  if mode!='CONTROL':
   self.med=official_med()
   self.layer_adapters=nn.ModuleList([nn.Conv2d(768,64,1) for _ in range(4)])
   self.fusion=nn.Sequential(nn.Conv2d(256,128,1),nn.SiLU())
   self.global_projection=nn.Linear(128,256)
   nn.init.zeros_(self.global_projection.weight);nn.init.zeros_(self.global_projection.bias)
   if mode=='MED_S':
    self.spatial_projections=nn.ModuleDict({s:nn.Conv2d(128,self.dacb[s].mamba.d_inner,1) for s in SPATIAL})
    for m in self.spatial_projections.values():nn.init.zeros_(m.weight);nn.init.zeros_(m.bias)
 def train(self,mode=True):
  super().train(mode)
  if self.mode!='CONTROL':self.med.eval().requires_grad_(False)
  return self
 @torch.no_grad()
 def extract(self,center):
  assert center.shape[1:]==(1,512,512)
  hu=(center*4096-1024).clamp(-1000,1000)
  image=((hu-MEAN_HU)/STD_HU).repeat(1,3,1,1)
  assert torch.isfinite(image).all()
  ts=self.med.get_intermediate_layers(image,n=[2,5,8,11],norm=True,return_class_token=False,return_extra_tokens=False)
  assert len(ts)==4 and all(t.shape==(center.shape[0],1024,768) for t in ts)
  self.extract_calls+=1
  return tuple(t.transpose(1,2).reshape(center.shape[0],768,32,32).contiguous().detach() for t in ts)
 def set_context(self,center,patches=None):
  self._spatial={}
  if self.mode=='CONTROL':
   assert patches is None
   self._c=torch.zeros(center.shape[0],1,256,device=center.device)
   return
  maps=self.extract(center) if patches is None else patches
  a=self.fusion(torch.cat([m(p) for m,p in zip(self.layer_adapters,maps)],1))
  assert a.shape==(center.shape[0],128,32,32)
  self._c=self.global_projection(a.mean((-2,-1)))[:,None,:]
  if self.meddino_off:self._c=self._c*0
  if self.mode=='MED_S':
   for s in SPATIAL:
    size=STAGES[s][2]
    self._spatial[s]=self.spatial_projections[s](F.interpolate(a,size=(size,size),mode='bilinear',align_corners=False))
    assert self._spatial[s].shape==(center.shape[0],self.dacb[s].mamba.d_inner,size,size)
    if self.spatial_off or self.meddino_off:self._spatial[s]=self._spatial[s]*0
  if self.record:self.activity.append({'stage':'CONDITION','c_rms':rms(self._c),'fused_rms':rms(a)})
 def clear_context(self):
  self._c=None;self._spatial={}
  for m in self.dacb.values():m.mamba._spatial_context=None
 def update_branch(self,s,x,t):
  assert self._c is not None and self._c.shape==(x.shape[0],1,256)
  if self.branch_off:return x
  m=self.dacb[s];m.mamba._spatial_context=self._spatial.get(s)
  y=m(x,self._c,t)
  if self.record:
   b=rms(x);d=rms(y-x);sp=m.mamba._spatial_context
   self.activity.append({'stage':s,'base_rms':b,'delta_rms':d,'delta_base_ratio':d/max(b,1e-30),'spatial_rms':0. if sp is None else rms(sp),'c_rms':rms(self._c)})
  return y.contiguous() # preserve parent BCHW contiguous convolution path
 def forward(self,x,time,x_self_cond=None):
  assert not self.self_condition and x.shape[1]==2
  self.forward_calls+=1
  x=self.init_conv(x);r=x.clone();t=self.time_mlp(time);h=[]
  for i,(block,downsample) in enumerate(self.downs):
   x=self.update_branch('E'+str(i),x,t) # Official encoder Mamba BEFORE RLEB
   x=block(x,t);h.append(x);x=downsample(x)
  x=self.mid_block(x,t);x=self.update_branch('MID',x,t)
  for i,(block,upsample) in enumerate(self.ups):
   x=torch.cat((x,h.pop()),1);x=block(x,t);x=self.update_branch('D'+str(i),x,t);x=upsample(x)
  x=torch.cat((x,r),1);x=self.final_res_block(x,t);return self.final_conv(x)
def build(mode,common=None):
 # Construction does not advance any training RNG; all extra common parameters seeded identically.
 with torch.random.fork_rng(devices=[]):
  torch.manual_seed(20260829)
  diffusion=build_baseline()
  state=torch.load(PARENT,map_location='cpu',weights_only=False)['ema_state_dict']
  diffusion.load_state_dict(state,strict=True)
  u=CSSMUnet(mode)
  parent_u=diffusion.model.unet0.state_dict()
  own=u.state_dict();assert all(n in own and own[n].shape==t.shape for n,t in parent_u.items())
  own.update(parent_u);u.load_state_dict(own,strict=True)
  diffusion.model.unet0=u
  if common is not None:
   loaded=diffusion.state_dict()
   assert all(n in loaded and loaded[n].shape==t.shape for n,t in common.items())
   loaded.update(common);diffusion.load_state_dict(loaded,strict=True)
 return diffusion
def common_state(model):
 return {n:t.detach().cpu().clone() for n,t in model.state_dict().items() if not any('.'+p+'.' in n for p in ('med','layer_adapters','fusion','global_projection','spatial_projections'))}
def med_state_hash(model):
 return None if model.model.unet0.mode=='CONTROL' else statehash(model.model.unet0.med.state_dict())
