# 尚未执行的验证方案

本文件只提出证明路径，不授权或启动任何推理、训练或 L333 验证。

1. 若用户另行授权，在**固定合成张量**上通过只读 hook 记录九处 Mamba_block 的 gate_msa(t)、gate_mlp(t)、SS2D c-local 和 E2/MID/D1 spatial tensor 的真实 RMS/shape；分别读取已完成 checkpoint，不更新权重。需在固定 timestep 列表及相同输入下比较。
2. 若需检验缓存，对一张另行授权的固定样本逐 forward 记录 LDCT 特征/条件 SHA、set_context/clear_context 次数，确认同一采样的两次 forward 完全复用，跨样本无残留。检查 eval 与 train 路由只在 dropout/冻结状态上有预期差异。
3. 若需解释关闭空间条件的微小结果，在同一现成 MED_S EMA、固定种子上分别测 NORMAL、GLOBAL_OFF、SPATIAL_OFF、BOTH_OFF，并记录逐阶段输出变化与 gate(t)；如涉及 L333-fast64，须重新取得用户授权，不能复用本轮只读审计授权。
4. 若要修复可追溯性，未来新实验应记录 Python random 状态、实际 gate(t) RMS，并以 CONFIG_6K 生成报告元数据。不得改动本次原实验文件或重新解释已完成结果。
