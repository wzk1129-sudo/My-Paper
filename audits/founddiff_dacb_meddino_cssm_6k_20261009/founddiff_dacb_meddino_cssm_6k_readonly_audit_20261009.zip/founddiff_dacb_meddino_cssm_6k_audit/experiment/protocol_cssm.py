"""Allowlisted center-only data and unchanged metric protocol; no directory enumeration."""
from pathlib import Path
import json,hashlib,csv,random,contextlib,os,time,math
import numpy as np
import torch
from model_cssm import ROOT
from frozen_protocol import normalize_stored_ct,slice_metrics
CFG=json.loads((ROOT/'METRIC_CONFIG.json').read_text())
METRICS=('psnr','ssim','rmse_hu','mae_hu')
COUNTS={'L067':560,'L143':585,'L333':610}
INDICES=tuple(int(s) for s in (ROOT/'L333_fast64.txt').read_text().split() if s.strip())
assert len(INDICES)==64 and len(set(INDICES))==64 and all(0<=i<610 for i in INDICES)
def write(path,value):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2,allow_nan=False));os.replace(tmp,path)
def csvwrite(path,rows):
 if not rows:return
 with Path(path).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def seed(seed=20260829):
 random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
 torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
 torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
 torch.use_deterministic_algorithms(True);torch.set_num_threads(2)
class AccessGuard:
 def __init__(self):
  self.counts={p:{'LDCT':0,'NDCT_center_target':0} for p in COUNTS};self.blocked=0;self.original=np.load
 def guarded(self,path,*args,**kwargs):
  p=Path(path).resolve()
  root=Path(CFG['data']['root']).resolve()
  a=p.stem.split('_')
  allowed=p.parent==root and len(a)==4 and a[0] in COUNTS and a[1] in ('25','target') and a[3]=='img' and a[2].isdigit() and 0<=int(a[2])<COUNTS.get(a[0],0)
  if allowed and a[0]=='L333':allowed=int(a[2]) in INDICES
  if not allowed:self.blocked+=1;raise PermissionError('Blocked non-allowlisted data access')
  self.counts[a[0]]['LDCT' if a[1]=='25' else 'NDCT_center_target']+=1
  return self.original(path,*args,**kwargs)
 def __enter__(self):np.load=self.guarded;return self
 def __exit__(self,*args):np.load=self.original
 def report(self):return {'per_patient_array_opens':self.counts,'L506_opens':0,'external_memory_opens':0,'neighbor_NDCT_opens':0,'blocked_attempts':self.blocked,'NDCT_role':'center reconstruction target only; never condition input','scope':'np.load guard for all array accesses; no directory enumeration or other data readers'}
class Pairs:
 def __init__(self,split):
  self.records=[(p,i) for p in ('L067','L143') for i in range(COUNTS[p])] if split=='train' else [('L333',i) for i in INDICES]
  assert split in ('train','val');self.manifest_sha=hashlib.sha256(json.dumps(self.records,separators=(',',':')).encode()).hexdigest()
 def __len__(self):return len(self.records)
 def load(self,pos):
  p,i=self.records[pos];arrays=[]
  for view in ('25','target'):
   path=Path(CFG['data']['root'])/f'{p}_{view}_{i:03d}_img.npy'
   x=np.load(path,allow_pickle=False);assert x.shape==(512,512) and np.isfinite(x).all()
   x=normalize_stored_ct(x,CFG['data']);assert x.dtype==np.float32 and x.min()>=0 and x.max()<=1
   arrays.append(x[None])
  return *arrays,{'patient_id':p,'slice_index':i}
class Stream:
 def __init__(self,pairs):
  self.pairs=pairs;self.rng=np.random.RandomState(20260829);self.order=self.rng.permutation(len(pairs));self.cursor=0;self.epoch=0
 def next(self,batch):
  xs=[];ys=[];meta=[]
  for _ in range(batch):
   if self.cursor==len(self.order):self.order=self.rng.permutation(len(self.pairs));self.cursor=0;self.epoch+=1
   j=int(self.order[self.cursor]);self.cursor+=1;x,y,m=self.pairs.load(j);flip=bool(self.rng.rand()<.5);rot=int(self.rng.randint(4))
   def aug(a):
    if flip:a=np.flip(a,axis=-1)
    return np.ascontiguousarray(np.rot90(a,rot,axes=(-2,-1)))
   xs.append(aug(x));ys.append(aug(y));meta.append({**m,'horizontal_flip':flip,'rotation_degrees':90*rot})
  return torch.from_numpy(np.stack(xs)),torch.from_numpy(np.stack(ys)),meta
 def state_dict(self):return {'rng':self.rng.get_state(),'permutation':self.order,'cursor':self.cursor,'epoch':self.epoch,'manifest':self.pairs.manifest_sha}
@torch.no_grad()
def validate(model,step,run,condition='NORMAL'):
 u=model.model.unet0;u.clear_context();model.eval();u.record=True;u.activity=[]
 u.meddino_off=condition=='MEDDINO_OFF';u.spatial_off=condition=='SPATIAL_OFF'
 data=Pairs('val');rows=[];start=time.perf_counter();before_extract=u.extract_calls;before_forward=u.forward_calls
 with torch.random.fork_rng(devices=[0]),open(os.devnull,'w') as quiet,contextlib.redirect_stderr(quiet):
  for j in range(len(data)):
   x,y,meta=data.load(j);x=torch.from_numpy(x)[None].cuda();y=torch.from_numpy(y)[None].cuda()
   u.set_context(x) # frozen LDCT features cached once for both sampling forwards
   s=20260829+meta['slice_index'];torch.manual_seed(s);torch.cuda.manual_seed(s)
   pred=model.sample([x],last=True)[-1]
   assert pred.shape==y.shape and torch.isfinite(pred).all()
   v=slice_metrics(pred,y,CFG);assert all(math.isfinite(v[k]) for k in METRICS)
   rows.append({'variant':u.mode,'step':step,'condition':condition,**meta,**{k:v[k] for k in METRICS},'sampling_seed':s})
   u.clear_context()
 torch.cuda.synchronize()
 summary={'variant':u.mode,'step':step,'condition':condition,'slices':64,**{k:float(np.mean([r[k] for r in rows])) for k in METRICS},'validation_seconds':time.perf_counter()-start}
 assert u.forward_calls-before_forward==128
 assert u.extract_calls-before_extract==(0 if u.mode=='CONTROL' else 64)
 write(run/f'EMA_FAST64_STEP_{step}_{condition}.json',summary)
 csvwrite(run/f'PER_SLICE_STEP_{step}_{condition}.csv',rows)
 write(run/f'CONDITION_ACTIVITY_STEP_{step}_{condition}.json',{'rows':u.activity,'extractions':u.extract_calls-before_extract,'diffusion_forwards':u.forward_calls-before_forward})
 u.record=False;u.activity=[];u.meddino_off=False;u.spatial_off=False
 return summary,rows
