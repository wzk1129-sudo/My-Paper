"""Seeded native CUDA forward/backward reference witness; never used as a model backend."""
import sys,json,hashlib
from pathlib import Path
import torch
from torch.nn import functional as F
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'runtime/extensions'));sys.path.insert(0,str(R/'vendor'))
from official_ss2d import SelectiveScan,SS2D,SSMODE
torch.set_num_threads(2);torch.manual_seed(20260829);torch.cuda.manual_seed_all(20260829)
torch.backends.cuda.matmul.allow_tf32=False
inputs=[torch.randn(2,8,64,device='cuda'),torch.randn(2,8,64,device='cuda')*.2,-torch.rand(8,4,device='cuda'),torch.randn(2,4,4,64,device='cuda')*.2,torch.randn(2,4,4,64,device='cuda')*.2,torch.randn(8,device='cuda'),torch.randn(8,device='cuda')*.1]
inputs=[x.requires_grad_() for x in inputs]
out=SelectiveScan.apply(*inputs,True,1)
assert torch.isfinite(out).all()
grads=torch.autograd.grad(out.square().mean(),inputs)
refs=[x.detach().clone().requires_grad_() for x in inputs]
u,delta,A,B,C,D,bias=refs
dt=F.softplus(delta+bias[None,:,None]);Bs=B.repeat_interleave(2,1);Cs=C.repeat_interleave(2,1)
state=torch.zeros(2,8,4,device='cuda');ys=[]
for t in range(64):
 state=torch.exp(dt[:,:,t,None]*A[None])*state+dt[:,:,t,None]*Bs[:,:,:,t]*u[:,:,t,None]
 ys.append((state*Cs[:,:,:,t]).sum(-1)+D[None]*u[:,:,t])
ref=torch.stack(ys,-1)
rgrads=torch.autograd.grad(ref.square().mean(),refs)
diff=float((out-ref).abs().max())
gdiff=[float((x-y).abs().max()) for x,y in zip(grads,rgrads)]
assert torch.allclose(out,ref,atol=2e-4,rtol=2e-4)
assert all(torch.allclose(x,y,atol=2e-4,rtol=3e-4) for x,y in zip(grads,rgrads))
repeat=SelectiveScan.apply(*inputs,True,1);assert torch.equal(repeat,out)
layer=SS2D(d_model=16,d_state=4,dropout=0).cuda()
x=torch.randn(2,8,8,16,device='cuda',requires_grad=True);c=torch.zeros(2,1,256,device='cuda',requires_grad=True)
y=layer(x,c);y.square().mean().backward()
assert y.shape==x.shape and torch.isfinite(y).all() and all(p.grad is not None and torch.isfinite(p.grad).all() for p in layer.parameters())
assert x.grad.abs().sum()>0 and torch.isfinite(x.grad).all()
audit={'status':'PASS','backend':SSMODE,'shape':list(out.shape),'forward_max_abs_error_to_reference':diff,'backward_max_abs_errors':gdiff,'repeat_bitwise_equal':True,'SS2D_shape':list(y.shape),'SS2D_gradients_finite':True,'SS2D_input_gradient_nonzero':True,'torch':torch.__version__,'CUDA':torch.version.cuda,'GPU':torch.cuda.get_device_name(0),'reference_used_in_model':False}
(R/'runtime/KERNEL_WITNESS.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit),flush=True)
