# Architecture audit

## Source identity and scope
Official FoundDiff repository commit c85a3a0e87ae2e4587650f0fb7efc15f3311d8e2; DADiff.py and emamba2.py hashed in audits/UPSTREAM_SOURCE_MANIFEST.json.
Parent is archived FoundDiff_RDDM_RLEB@60k EMA, SHA256 49aa8ce2ee5c98c4deeaf3067d7059f54f18d7715e30439cd9326b6177867469.
The parent is RDDM + RLEB, NOT complete FoundDiff. These candidates are center-LDCT CT adaptations using official Mamba_block/SS2D/TransposedAttention; they are NOT a reproduction of the original DA-CLIP FoundDiff experiment.

## Parent preservation and official ordering
Every parent state key is retained with its exact value; no parameters are dropped or ignored.
The old RLEB includes its historically restored time MLP. Official FoundDiff ResnetBlock comments this path out. We retain the old trained RLEB time path, as required by the preferred compatible initialization; do not strip those weights to imitate a strict official Unet load.
Official encoder order: Mamba update -> RLEB -> skip -> downsample.
Official middle: RLEB -> Mamba update.
Official decoder: concatenate skip -> RLEB -> Mamba update -> upsample.
The original LDCT input, initial skip, time embedding, final RLEB and residual head remain unchanged.
Nine official Mamba updates have original adaLN-Zero gates. At initialization their residual updates are zero.
BCHW output is made contiguous before the existing convolutions so the parent's convolution layout is preserved.
Step0 active-zero and branch-disabled output identity are measured, not inferred.

## Stage table
Stage | Mamba d_model | d_state | spatial size | spatial injection
E0 | 64 | 4 | 512 | no
E1 | 64 | 8 | 256 | no
E2 | 128 | 16 | 128 | yes (MED-S)
E3 | 256 | 32 | 64 | no
MID | 512 | 32 | 64 | yes (MED-S)
D0 | 512 | 32 | 64 | no
D1 | 256 | 16 | 128 | yes (MED-S)
D2 | 128 | 8 | 256 | no
D3 | 64 | 4 | 512 | no

E/D indices mean execution order, zero-based. Actual d_inner is derived from the official SS2D x_proj_weight last dimension, not hardcoded. Effective ssm_ratio/ssm_rank_ratio are the official default 2.0; Mamba_block's expand keyword is swallowed by official **kwargs.

## Condition interfaces
CONTROL constructs no MedDINO module; c is exactly zeros [B,1,256].
MED-G: frozen ViT-B/16 layers [2,5,8,11] -> 768-channel 32x32 maps -> four 768-to-64 1x1 adapters -> concatenate 256 channels -> 1x1 Conv256-to-128 + SiLU -> GAP -> zero-init Linear128-to-256.
Projection/fusion architecture and preprocessing are copied from validated V1; newly added trainable adapters/fusion share identical seeded initialization across MED-G and MED-S, not a trained candidate checkpoint.
The original CSSM c path is Linear256-to-d_inner(no bias)+SiLU, added after scan/z-gating before out_proj. This is retained exactly.
MED-S additionally interpolates the fused map with bilinear align_corners=False; zero-init Conv1x1 maps 128 channels to each official d_inner at E2/MID/D1. It adds after depthwise convolution+SiLU and before unchanged selective scan.
The selective scan recurrence, EfficientScan/Merge directions/step_size2, state parameters, native z gate, TransposedAttention and RDDM equations are unchanged.
SS2D source diff consists of the optional spatial addition and omission of an unused ipdb import. Official blocks are extracted verbatim; unused DA-CLIP/CrossAttention/dose/prompt classes are not imported.

## Input and normalization
Network: [x_t, center LDCT], never neighbor slices.
Stored CT -> HU offset -1024 -> clip [-1024,3072] -> [0,1] for original RDDM.
MedDINO: center [0,1] -> HU via x*4096-1024 -> clip [-1000,1000] -> (HU-65.1084213256836)/178.01663208007812 -> repeat one center image to 3 channels.
Frozen MedDINO eval(), no optimizer membership; SHA256 492b2b96c00e9d3b93ba3b07a8d387aa2196b5e04698378fcc23049b447966d2.
Features are extracted once per LDCT image and cached across both sampling forwards. NDCT only enters residual supervision or evaluation, never condition construction.

## CUDA backend
The original emamba2.py explicitly falls back from VMamba extension to selective_scan_cuda (SSMODE=mamba_ssm).
Unchanged upstream Mamba v2.2.6 native CUDA sources are compiled locally to this experiment only. flexict is read-only, no packages installed, no Python scan fallback used in the model.
A Python recurrence is used only to test native CUDA values/gradients; it is not a training/inference backend.

## Frozen protocol
Three variants start from COMMON_INITIAL_STATE.pt with fresh Adam/EMA/RNG, not one another.
seed20260829, Adam2e-4/betas(.9,.99)/weight_decay1e-9, EMA.995 every step, no warmup, clip1, AMPFalse, effective batch2.
2k/4k/6k/8k EMA Fast64 validation; no L506, no external memory; no extra loss, 2.5D, DFFN, FFL, Sobel, NSE, DA-CLIP or cross-attention.
Stream witness includes augmented inputs/targets, patient/slice metadata, timesteps and noise tensor hashes; every step of MED-G/MED-S must match CONTROL.
