"""One subprocess at a time; fail closed on validity/runtime exceptions."""
import subprocess,json,traceback,sys,datetime
from pathlib import Path
R=Path(__file__).resolve().parent
def write(name,x):(R/name).write_text(json.dumps(x,indent=2))
def main():
 pre=json.loads((R/'PREFLIGHT_AUDIT.json').read_text());assert pre['status']=='PASS'
 for m in ('CONTROL','MED_G','MED_S'):
  assert not subprocess.check_output(['/usr/lib/wsl/lib/nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip(),'GPU occupied by another process; stop without competing'
  print('SERIAL_START',m,datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
  with (R/'logs'/f'{m}.train_6k.log').open('x') as f:
   subprocess.run([sys.executable,'-u',str(R/'train_cssm_6k.py'),m],stdout=f,stderr=subprocess.STDOUT,check=True,cwd='/home/xujian/projects/CoreDiff')
  final=json.loads((R/m/'FINAL_STATE.json').read_text())
  assert final['status']=='PASS' and final['optimizer_step']==6000 and final['NaN_Inf_overflow_optimizer_skip']==0
  assert final['data_access']['L506_opens']==final['data_access']['external_memory_opens']==final['data_access']['blocked_attempts']==0
  print('SERIAL_COMPLETE',m,flush=True)
 with (R/'logs/final_report_6k.log').open('x') as f:
  subprocess.run([sys.executable,'-u',str(R/'summarize_6k.py')],stdout=f,stderr=subprocess.STDOUT,check=True,cwd='/home/xujian/projects/CoreDiff')
 assert json.loads((R/'PIPELINE_COMPLETE.json').read_text())['status']=='PASS'
if __name__=='__main__':
 try:main()
 except Exception:
  write('PIPELINE_6K_FAILURE.json',{'traceback':traceback.format_exc(),'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'no_automatic_retry':True})
  write('STATUS.json',{'state':'PIPELINE_FAILED_QUEUE_STOPPED'})
  raise
