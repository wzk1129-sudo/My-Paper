# Preflight report

PASS. 100 optimizer steps per variant; all discarded; formal runs start from COMMON_INITIAL_STATE.pt with fresh Adam/EMA/RNG.

Batch 2, accumulation 1. Parent disabled-branch identity exact; active zero branch tolerance 1e-6.

Global/spatial projections have zero gradients at the initial backward because official adaLN gate is also zero. Both have nonzero finite gradients at the second backward after the first gate update. This is expected nested-zero initialization, not a disconnected branch.

- CONTROL: 1.0906 sec/step; allocated 21.696 GiB; reserved 22.590 GiB; trainable 26227263

- MED_G: 2.1099 sec/step; allocated 22.422 GiB; reserved 23.352 GiB; trainable 26490047

- MED_S: 1.8533 sec/step; allocated 22.594 GiB; reserved 23.523 GiB; trainable 26721215

Estimated training-only serial wall time: 11.230505367937601 hours, plus validation/checkpoint time.