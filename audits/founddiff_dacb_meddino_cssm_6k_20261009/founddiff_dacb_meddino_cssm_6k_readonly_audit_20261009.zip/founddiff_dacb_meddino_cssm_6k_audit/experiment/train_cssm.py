"""Strict serial matched training from common parent; no retries or protocol changes."""
from pathlib import Path
import sys,json,time,copy,gc,traceback,hashlib,os,subprocess
import numpy as np
import torch
from model_cssm import *
from protocol_cssm import *
VARIANTS=('CONTROL','MED_G','MED_S')
def finite(model):
 assert all(torch.isfinite(p).all() for p in model.parameters())
def check_sources():
 pins=json.loads((ROOT/'SOURCE_MANIFEST.json').read_text())
 for p,h in pins.items():assert sha(p)==h,'Source changed: '+p
def saveck(path,payload):
 tmp=path.with_suffix('.tmp');torch.save(payload,tmp);os.replace(tmp,path)
 ck=torch.load(path,map_location='cpu',weights_only=False)
 assert ck['step']==payload['step'] and statehash(ck['model'])==statehash(payload['model'])
 assert statehash(ck['ema'])==statehash(payload['ema']) and ck['ema_updates']==ck['step']
 audit={'status':'PASS','step':ck['step'],'sha256':sha(path),'cpu_reload':True,'model_hash':statehash(ck['model']),'ema_hash':statehash(ck['ema']),'has_full_optimizer_RNG_stream':all(k in ck for k in ('optimizer','rng','stream','noise_generator'))}
 write(path.with_suffix('.audit.json'),audit)
 return audit
def cpu_state(m):return {n:t.detach().cpu().clone() for n,t in m.state_dict().items()}
def grads(model):
 groups={}
 for n,p in model.named_parameters():
  if not p.requires_grad:assert p.grad is None;continue
  assert p.grad is not None and torch.isfinite(p.grad).all(),n
  g='global_projection' if 'global_projection' in n else 'spatial' if 'spatial_projections' in n else 'dacb' if '.dacb.' in n else 'main'
  groups[g]=groups.get(g,0.)+float(p.grad.detach().square().sum())
 return {k:v**.5 for k,v in groups.items()}
def gpu_gate():
 raw=subprocess.check_output(['/usr/lib/wsl/lib/nvidia-smi','--query-compute-apps=pid,used_memory','--format=csv,noheader,nounits'],text=True).strip()
 for line in raw.splitlines():
  pid=line.split(',')[0].strip()
  assert pid==str(os.getpid()),'Other GPU process present; do not compete: '+line
 return raw
def run(mode):
 assert mode in VARIANTS;check_sources();gpu_gate();config=json.loads((ROOT/'CONFIG.json').read_text())
 assert config['steps']==8000 and config['status']=='PREFLIGHT_PASS'
 run=ROOT/mode;assert not run.exists(),'Refuse to overwrite or duplicate existing run';run.mkdir();(run/'checkpoints').mkdir()
 bundle=torch.load(ROOT/'COMMON_INITIAL_STATE.pt',map_location='cpu',weights_only=False);common=bundle['common_state']
 model=build(mode,common).cuda();assert statehash(common_state(model))==bundle['hash']
 initial_hash=statehash(model.state_dict());u=model.model.unet0
 condition_initial_hash=None if mode=="CONTROL" else statehash({n:t for n,t in model.state_dict().items() if any("."+k+"." in n for k in ("layer_adapters","fusion","global_projection"))})
 if mode=="MED_S":
  assert condition_initial_hash==json.loads((ROOT/"MED_G/FRESH_START_AUDIT.json").read_text())["global_condition_initial_hash"]
 frozen_hash=med_state_hash(model)
 ema=copy.deepcopy(model).eval().requires_grad_(False);ema_updates=0
 optimizer=torch.optim.Adam([p for p in model.parameters() if p.requires_grad],lr=2e-4,betas=(.9,.99),weight_decay=1e-9)
 assert not optimizer.state;seed()
 noisegen=torch.Generator(device='cuda').manual_seed(20260829)
 pairs=Pairs('train');stream=Stream(pairs);batch=config['batch'];accum=config['accumulation'];assert batch*accum==2
 write(run/'FRESH_START_AUDIT.json',{'status':'PASS','common_hash':bundle['hash'],'initial_full_hash':initial_hash,'global_condition_initial_hash':condition_initial_hash,'fresh_Adam_empty_state':True,'seed':20260829,'manifest_hash':pairs.manifest_sha,'no_previous_variant_checkpoint_loaded':True,'MedDINO_parameter_hash':frozen_hash})
 reference=[]
 if mode!='CONTROL':
  reference=[json.loads(s) for s in (ROOT/'CONTROL/TRAIN_STREAM.jsonl').read_text().splitlines()]
  assert len(reference)==8000
 history=[];timing=[];chain='0'*64;guards=None
 try:
  with AccessGuard() as guard:
   guards=guard
   summary,rows=validate(ema,0,run)
   if mode!='CONTROL':
    cr=json.loads((ROOT/'CONTROL/EMA_FAST64_STEP_0_NORMAL.json').read_text())
    assert all(summary[k]==cr[k] for k in METRICS),'Step0 metrics differ from Control'
   history.append(summary);csvwrite(run/'VALIDATION_HISTORY.csv',history)
   write(ROOT/'STATUS.json',{'state':'TRAINING','variant':mode,'step':0,'maximum':8000})
   torch.cuda.reset_peak_memory_stats();started=time.perf_counter()
   with (run/'TRAIN_STREAM.jsonl').open('w',buffering=1) as streamlog,(run/'TRAIN_LOG.jsonl').open('w',buffering=1) as log:
    for step in range(1,8001):
     if step%100==1:check_sources();gpu_gate()
     t0=time.perf_counter();model.train();optimizer.zero_grad(set_to_none=True);lossvalue=0.;realizations=[]
     for micro in range(accum):
      x,y,metadata=stream.next(batch);x=x.cuda();y=y.cuda()
      tt=torch.randint(0,1000,(batch,),device='cuda',generator=noisegen);noise=torch.randn(x.shape,device='cuda',generator=noisegen)
      h=hashlib.sha256()
      for t in (x,y,tt,noise):h.update(t.detach().cpu().contiguous().numpy().tobytes())
      realizations.append({'micro':micro,'samples':metadata,'timestep':tt.tolist(),'tensor_sha256':h.hexdigest()})
      u.set_context(x)
      loss=model.p_losses([y*2-1,x*2-1],tt,noise)[0]/accum;assert torch.isfinite(loss);loss.backward();lossvalue+=float(loss.detach());u.clear_context()
     g=grads(model)
     norm=torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],1.,error_if_nonfinite=True)
     optimizer.step();finite(model)
     with torch.no_grad():
      for ep,p in zip(ema.parameters(),model.parameters()):
       if p.requires_grad:ep.mul_(.995).add_(p,alpha=.005)
       else:ep.copy_(p)
      for eb,b in zip(ema.buffers(),model.buffers()):eb.copy_(b)
     ema_updates+=1
     record={'step':step,'realizations':realizations}
     token=hashlib.sha256(json.dumps(record,sort_keys=True,separators=(',',':')).encode()).hexdigest()
     chain=hashlib.sha256((chain+token).encode()).hexdigest();record.update({'step_hash':token,'chain':chain})
     if reference:assert record==reference[step-1],f'Data/noise stream mismatch at {step}'
     streamlog.write(json.dumps(record,separators=(',',':'))+'\n')
     torch.cuda.synchronize();secs=time.perf_counter()-t0;timing.append(secs)
     allocated=torch.cuda.max_memory_allocated()/2**30;reserved=torch.cuda.max_memory_reserved()/2**30
     row={'step':step,'loss':lossvalue,'grad_norm_pre_clip':float(norm),'seconds':secs,'peak_allocated_GiB':allocated,'peak_reserved_GiB':reserved,'gradient_groups':g,'stream_hash':token,'NaN_Inf_overflow_optimizer_skip':0}
     log.write(json.dumps(row)+'\n')
     if step%100==0:
      print(mode,json.dumps(row),flush=True)
      write(run/'STATUS.json',{'state':'TRAINING','variant':mode,**row});write(ROOT/'STATUS.json',{'state':'TRAINING','variant':mode,**row})
      write(run/'DATA_ACCESS_AUDIT.json',guard.report())
     if step%1000==0:
      assert med_state_hash(model)==frozen_hash and med_state_hash(ema)==frozen_hash
      payload={'step':step,'variant':mode,'model':cpu_state(model),'ema':cpu_state(ema),'optimizer':optimizer.state_dict(),'ema_updates':ema_updates,'rng':{'torch':torch.get_rng_state(),'cuda':torch.cuda.get_rng_state_all(),'numpy':np.random.get_state()},'noise_generator':noisegen.get_state(),'stream':stream.state_dict(),'stream_chain':chain,'config':config,'source_manifest':json.loads((ROOT/'SOURCE_MANIFEST.json').read_text()),'common_init_hash':bundle['hash'],'MedDINO_hash':frozen_hash}
      ck=run/'checkpoints'/f'step_{step}.pt';audit=saveck(ck,payload);del payload;gc.collect()
     if step%2000==0:
      summary,rows=validate(ema,step,run);history.append(summary);csvwrite(run/'VALIDATION_HISTORY.csv',history)
      print('EMA_VALIDATION',json.dumps(summary),flush=True)
      write(run/'DATA_ACCESS_AUDIT.json',guard.report())
   if mode!='CONTROL':
    off,_=validate(ema,8000,run,'MEDDINO_OFF')
    if mode=='MED_S':validate(ema,8000,run,'SPATIAL_OFF')
   check_sources();finite(model);assert ema_updates==8000 and med_state_hash(model)==frozen_hash and med_state_hash(ema)==frozen_hash
   access=guard.report();assert access['blocked_attempts']==0
   final={'status':'PASS','variant':mode,'optimizer_step':8000,'EMA_updates':ema_updates,'common_init_hash':bundle['hash'],'final_model_hash':statehash(model.state_dict()),'MedDINO_before_after_equal':True,'MedDINO_hash':frozen_hash,'stream_chain':chain,'stream_matches_CONTROL_all8000':True if mode!='CONTROL' else 'canonical reference','NaN_Inf_overflow_optimizer_skip':0,'mean_sec_per_step':float(np.mean(timing)),'median_sec_per_step':float(np.median(timing)),'peak_allocated_GiB':torch.cuda.max_memory_allocated()/2**30,'peak_reserved_GiB':torch.cuda.max_memory_reserved()/2**30,'trainable_parameters':sum(p.numel() for p in model.parameters() if p.requires_grad),'all_parameters':sum(p.numel() for p in model.parameters()),'data_access':access,'final_checkpoint_sha256':sha(run/'checkpoints/step_8000.pt')}
   write(run/'FINAL_STATE.json',final);write(run/'DATA_ACCESS_AUDIT.json',access);write(run/'STATUS.json',{'state':'COMPLETE','step':8000})
   print('VARIANT_COMPLETE',mode,flush=True)
 except Exception:
  write(run/'TRAIN_FAILURE.json',{'variant':mode,'step':locals().get('step',0),'traceback':traceback.format_exc(),'data_access':None if guards is None else guards.report()})
  write(ROOT/'STATUS.json',{'state':'FAILED_QUEUE_STOPPED','variant':mode,'step':locals().get('step',0)})
  raise
if __name__=='__main__':run(sys.argv[1])
