"""Build unchanged upstream selective_scan_cuda into this experiment only."""
from pathlib import Path
import hashlib,json,sys,subprocess,traceback
import torch
from torch.utils.cpp_extension import load
R=Path(__file__).resolve().parent
C=R/'vendor/mamba-2.2.6/csrc/selective_scan'
B=R/'runtime/extensions'
B.mkdir(parents=True,exist_ok=True)
names=['selective_scan.cpp','selective_scan_fwd_fp32.cu','selective_scan_fwd_fp16.cu','selective_scan_fwd_bf16.cu','selective_scan_bwd_fp32_real.cu','selective_scan_bwd_fp32_complex.cu','selective_scan_bwd_fp16_real.cu','selective_scan_bwd_fp16_complex.cu','selective_scan_bwd_bf16_real.cu','selective_scan_bwd_bf16_complex.cu']
pins={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in C.iterdir() if p.is_file()}
pins['vendor/mamba-v2.2.6.tar.gz']=hashlib.sha256((R/'vendor/mamba-v2.2.6.tar.gz').read_bytes()).hexdigest()
(R/'runtime/KERNEL_SOURCE_MANIFEST.json').write_text(json.dumps(pins,indent=2))
try:
 m=load(name='selective_scan_cuda',sources=[str(C/n) for n in names],extra_include_paths=[str(C)],build_directory=str(B),extra_cflags=['-O3','-std=c++17'],extra_cuda_cflags=['-O3','-std=c++17','-U__CUDA_NO_HALF_OPERATORS__','-U__CUDA_NO_HALF_CONVERSIONS__','-U__CUDA_NO_BFLOAT16_OPERATORS__','-U__CUDA_NO_BFLOAT16_CONVERSIONS__','-U__CUDA_NO_BFLOAT162_OPERATORS__','-U__CUDA_NO_BFLOAT162_CONVERSIONS__','--expt-relaxed-constexpr','--expt-extended-lambda','--use_fast_math','--threads','1'],verbose=True)
 (R/'runtime/BUILD_RESULT.json').write_text(json.dumps({'status':'BUILT_WITNESS_PENDING','module':m.__file__,'sha256':hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest(),'torch':torch.__version__,'python':sys.version},indent=2))
 print('BUILD_COMPLETE',flush=True)
except Exception:
 (R/'runtime/BUILD_FAILURE.txt').write_text(traceback.format_exc())
 raise
